library(readxl)
library(dplyr)
library(tidyr)
rm = (list= ls())
setwd("F:\\OMSA\\FA23-MGT6203\\Group Project\\Data")
df_draft_txt <- read.csv("df_draft_associated_v1.csv",header=TRUE)
col_names <- colnames(df_draft_txt)
print(col_names)

# Calculate the summary statistics of the sentiment column
sentiment_summary <- summary(df_draft_txt$sentiment)
# Print the summary statistics
print(sentiment_summary)

# List of offensive words in lowercase
offensive_words <- c(
  "fuck", "shit", "ass", "dumb", "nah", "bae", "baller", "chill", "dank", "dope",
  "extra", "fleek", "gucci", "lit", "salty", "savage", "shook", "tea", "yas",
  "adulting", "amped", "awesome", "basic", "beat", "bet", "bestie", "bounce", "bougie",
  "bro", "bummer", "bussin'", "bust", "cancel", "clapback", "clutch", "cool", "corny",
  "cringe", "drip", "dude", "dunno", "epic fail", "ex", "fake woke", "finesse", "fire",
  "flake", "flex", "fomo", "freebie", "gas", "ghost", "goat", "gucci gang", "hype"
)

# Step 1: Convert all text to lowercase
df_draft_txt$text <- tolower(df_draft_txt$text)

# Step 2: Count the frequency of offensive words in the text
word_freq <- table(unlist(strsplit(df_draft_txt$text, " ")))

# Step 3: Filter the word frequency for offensive words
offensive_word_freq <- word_freq[names(word_freq) %in% offensive_words]

# Step 4: Get the top 20 most frequent offensive words
top_20_offensive_words <- head(sort(offensive_word_freq, decreasing = TRUE), 20)

# Print the result
print(top_20_offensive_words)

# Step 1: Convert all text to lowercase
df_draft_txt$text <- tolower(df_draft_txt$text)

# Create an empty data frame to store results
result_table <- data.frame(Word = character(20), Frequency = integer(20), TotalSentiment = numeric(20))

# Loop through the top 20 offensive words
for (i in 1:20) {
  word <- names(top_20_offensive_words)[i]
  freq <- top_20_offensive_words[i]
  total_sentiment <- 0  # Initialize total sentiment for the word
  
  # Loop through each row in the dataset
  for (row in 1:nrow(df_draft_txt)) {
    text <- df_draft_txt$text[row]
    sentiment_score <- df_draft_txt$sentiment[row]
    
    # Check if the offensive word is in the text of the row
    if (grepl(word, text)) {
      # If the word is found, add its sentiment score to the total_sentiment
      total_sentiment <- total_sentiment + sentiment_score
    }
  }
  
  # Store the result in the result_table
  result_table[i, ] <- c(word, freq, total_sentiment)
}

# Print the result table
print(result_table)

